<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\student;
use Illuminate\Support\Facades\file;

class studentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        student::factory()->count(10)->create(); 
        // $json = File::get('database/json/students.json');
        // $students = collect(Json_decode($json));
        //         $students->each(function($student){
        //             student::create([
        //                 'name' => $student->name,
        //                 'email' => $student->email
        // ]);
        //         });
        
    }
}
