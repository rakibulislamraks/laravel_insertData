<?php

namespace App\Http\Controllers;
use Illuminate\support\Facades\DB;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function showUser(){
        $users = DB::table('students')->get();
        // return $users;
        return view('welcome',['data'=>$users]);
    }
    public function singleUser(string $id){
        $users = DB::table('students')->where('id',$id)->get();
        // return $users;
        return view('user',['data'=>$users]);
    }
}
