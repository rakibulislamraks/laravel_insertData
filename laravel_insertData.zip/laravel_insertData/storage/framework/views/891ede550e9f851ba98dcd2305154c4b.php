<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<body>
    <table class="table">
        <thead>
            <th>Name</th>
            <th>age</th>
            <th>Email</th>
            <th>city</th>
            <th>address</th>
            <th>link</th>
        </thead>
        <tbody>
            <tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id =>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->age); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->city); ?></td>
                    <td><?php echo e($user->address); ?></td>
                    
                    <td><a class="btn btn-primary" href="<?php echo e(Route('view.user',$user->id)); ?>">view</a></td>
                </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
</body>
</html>


<?php /**PATH D:\laravel\example-app\resources\views/welcome.blade.php ENDPATH**/ ?>